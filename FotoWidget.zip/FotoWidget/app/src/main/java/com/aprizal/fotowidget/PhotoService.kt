package com.aprizal.fotowidget
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class PhotoService : RemoteViewsService() {
    override fun onGetViewFactory(i: Intent): RemoteViewsFactory = Factory(applicationContext)
}
class Factory(private val c: Context) : RemoteViewsService.RemoteViewsFactory {
    private var list = listOf<String>()
    override fun onCreate() {}
    override fun onDataSetChanged() { list = Store.uris(c) }
    override fun onDestroy() {}
    override fun getCount() = list.size
    override fun getViewAt(p: Int): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.item)
        try {
            val u = Uri.parse(list[p])
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u).use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 700) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            c.contentResolver.openInputStream(u).use {
                rv.setImageViewBitmap(R.id.img, BitmapFactory.decodeStream(it, null, o2))
            }
        } catch (e: Exception) {}
        rv.setOnClickFillInIntent(R.id.img, Intent())
        return rv
    }
    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount() = 1
    override fun getItemId(p: Int) = p.toLong()
    override fun hasStableIds() = true
}
