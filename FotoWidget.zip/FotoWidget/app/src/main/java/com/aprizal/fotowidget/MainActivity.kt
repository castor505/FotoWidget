package com.aprizal.fotowidget
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        info = TextView(this)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Store.LABELS)
        sp.setSelection(Store.sel(this))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, l: Long) {
                Store.p(this@MainActivity).edit().putInt("i", i).apply(); refresh()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        val btn = Button(this).apply { text = "Pilih foto (bisa banyak)" }
        btn.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 1)
        }
        ll.addView(TextView(this).apply { text = "Ganti foto setiap:" })
        ll.addView(sp); ll.addView(btn); ll.addView(info)
        setContentView(ll); refresh()
    }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc != 1 || res != RESULT_OK || d == null) return
        val l = mutableListOf<android.net.Uri>()
        d.clipData?.let { for (i in 0 until it.itemCount) l.add(it.getItemAt(i).uri) } ?: d.data?.let { l.add(it) }
        l.forEach { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {} }
        Store.p(this).edit().putString("u", l.joinToString("\n")).apply(); refresh()
    }
    private fun refresh() {
        info.text = "\n${Store.uris(this).size} foto dipilih. Tambahkan widget dari menu widget di home screen (1x1, 2x2, 4x2, 4x4)."
        val m = AppWidgetManager.getInstance(this)
        for (c in listOf(Widget1x1::class.java, Widget2x2::class.java, Widget4x2::class.java, Widget4x4::class.java)) {
            val ids = m.getAppWidgetIds(ComponentName(this, c))
            if (ids.isNotEmpty()) BaseWidget().onUpdate(this, m, ids)
        }
    }
}
