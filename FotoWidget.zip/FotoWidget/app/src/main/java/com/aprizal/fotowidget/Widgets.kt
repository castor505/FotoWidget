package com.aprizal.fotowidget
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

open class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val layout = c.resources.getIdentifier("flip_${Store.sec(c)}", "layout", c.packageName)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        for (id in ids) {
            val rv = RemoteViews(c.packageName, layout)
            val svc = Intent(c, PhotoService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                data = Uri.parse("w://$id/${Store.sec(c)}/${Store.uris(c).size}")
            }
            rv.setRemoteAdapter(R.id.flipper, svc)
            rv.setPendingIntentTemplate(R.id.flipper, open)
            m.updateAppWidget(id, rv)
            m.notifyAppWidgetViewDataChanged(id, R.id.flipper)
        }
    }
}
class Widget1x1 : BaseWidget()
class Widget2x2 : BaseWidget()
class Widget4x2 : BaseWidget()
class Widget4x4 : BaseWidget()
