package com.aprizal.fotowidget
import android.content.Context
object Store {
    val SEC = intArrayOf(1, 2, 3, 4, 5, 10, 15, 20, 30, 60)
    val LABELS = listOf("1 detik","2 detik","3 detik","4 detik","5 detik","10 detik","15 detik","20 detik","30 detik","1 menit")
    fun p(c: Context) = c.getSharedPreferences("w", 0)
    fun uris(c: Context) = p(c).getString("u", "")!!.split("\n").filter { it.isNotBlank() }
    fun sel(c: Context) = p(c).getInt("i", 4)
    fun sec(c: Context) = SEC[sel(c)]
}
